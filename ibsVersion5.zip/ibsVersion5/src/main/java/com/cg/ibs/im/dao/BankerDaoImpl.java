package com.cg.ibs.im.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import org.springframework.stereotype.Repository;

import com.cg.ibs.im.bean.BankAdmins;
import com.cg.ibs.im.exception.IBSCustomException;
import com.cg.ibs.im.util.JPAUtil;

@Repository("bankerDao")
public class BankerDaoImpl implements BankerDao{
	private BankAdmins bankAdmin;
	private EntityManager entityManager;
	
	public BankerDaoImpl() {
		super();
		bankAdmin = new BankAdmins();
		EntityTransaction transaction = JPAUtil.getTransaction();
		transaction.begin();
		bankAdmin.setAdminId("id1");
		bankAdmin.setPassword("pass1");
		entityManager = JPAUtil.getEntityManger();
		entityManager.merge(bankAdmin);
		transaction.commit();
	}
	
	@Override
	public boolean checkBankerLogin(String adminId, String password) throws IBSCustomException {
		boolean result = false;
		bankAdmin = entityManager.find(BankAdmins.class, adminId);
		if(bankAdmin!=null) {
			if(bankAdmin.getPassword().equals(password)) {
				result = true;
			}
		}
		return result;
	}
}
