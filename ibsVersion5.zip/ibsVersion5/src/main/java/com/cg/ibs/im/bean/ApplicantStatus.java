package com.cg.ibs.im.bean;

public enum ApplicantStatus {
	PENDING, APPROVED, DENIED;
}
