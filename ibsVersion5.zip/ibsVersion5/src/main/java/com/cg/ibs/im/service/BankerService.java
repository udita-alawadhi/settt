package com.cg.ibs.im.service;

import java.util.Set;

import com.cg.ibs.im.bean.AccountBean;
import com.cg.ibs.im.bean.AccountHoldingType;
import com.cg.ibs.im.bean.ApplicantBean;
import com.cg.ibs.im.bean.CustomerBean;
import com.cg.ibs.im.exception.IBSCustomException;

public interface BankerService {
	
	boolean verifyBankerLogin(String user, String password) throws IBSCustomException;
	
	Set<Long> viewPendingApplications() throws IBSCustomException;
	
	Set<Long> viewApprovedApplications() throws IBSCustomException;
	
	Set<Long> viewDeniedApplications() throws IBSCustomException;
	
	boolean updateCustomer(CustomerBean customer) throws IBSCustomException;
	
	String generatePassword(long applicantId);
	
	CustomerBean createNewCustomer(ApplicantBean applicant) throws IBSCustomException;

	boolean isApplicantPresentInPendingList(long applicantId) throws IBSCustomException;

	boolean isApplicantPresent(long applicantId) throws IBSCustomException;

	ApplicantBean displayDetails(long applicantId) throws IBSCustomException;

	String generateUsername(long applicantId) throws IBSCustomException;

	boolean download(ApplicantBean applicant) throws IBSCustomException;

	AccountBean createNewAccount(CustomerBean customer, AccountHoldingType aHType) throws IBSCustomException;
}
