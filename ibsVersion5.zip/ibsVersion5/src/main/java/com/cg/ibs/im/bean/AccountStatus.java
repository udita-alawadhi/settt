package com.cg.ibs.im.bean;

public enum AccountStatus {
	ACTIVE, CLOSED;
}
