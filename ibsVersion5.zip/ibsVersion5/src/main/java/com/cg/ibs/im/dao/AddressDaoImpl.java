package com.cg.ibs.im.dao;

import javax.persistence.EntityManager;

import org.springframework.stereotype.Repository;

import com.cg.ibs.im.bean.AddressBean;
import com.cg.ibs.im.exception.IBSCustomException;
import com.cg.ibs.im.exception.IBSException;
import com.cg.ibs.im.util.JPAUtil;

@Repository("addressDao")
public class AddressDaoImpl implements AddressDao {

	private EntityManager entityManager;
	
	public AddressDaoImpl() {
		entityManager = JPAUtil.getEntityManger();
	}
	
	@Override
	public Long saveAddress(AddressBean address) throws IBSCustomException {
		Long result = new Long(0);
		if (address != null) {
			entityManager.persist(address);
		} else {
			throw new IBSCustomException(IBSException.invalidApplicantId);
		}
		return result;
	}

	@Override
	public AddressBean getAddress(long applicantId) throws IBSCustomException {
		AddressBean address = new AddressBean();
		if (applicantId != 0) {
			address = entityManager.find(AddressBean.class, applicantId);
		} else {
			throw new IBSCustomException(IBSException.applicantNotFound);
		}
		return address;
	}

}
