package com.cg.ibs.im.model;

public class Account {

}
