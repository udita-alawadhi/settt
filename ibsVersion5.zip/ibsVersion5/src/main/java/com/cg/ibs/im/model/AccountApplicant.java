package com.cg.ibs.im.model;

import java.math.BigInteger;
import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name= "account_applicants")
public class AccountApplicant {

	@Id
	private Long accountApplicantId;
	private AccountType accountType;
	private AccountStatus accountStatus;
	private LocalDate accountApplicationDate;
	private Customer primaryCustomer;
	private Customer secondaryCustomer;
	
}
