package com.cg.ibs.im.bean;

public enum TransactionType {
	 CREDIT, DEBIT;
}
