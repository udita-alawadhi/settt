package com.cg.ibs.im.ui;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.ibs.im.bean.AccountHoldingBean;
import com.cg.ibs.im.bean.AccountType;
import com.cg.ibs.im.bean.AddressBean;
import com.cg.ibs.im.bean.ApplicantBean;
import com.cg.ibs.im.bean.ApplicantStatus;
import com.cg.ibs.im.bean.CustomerBean;
import com.cg.ibs.im.bean.Gender;
import com.cg.ibs.im.exception.IBSCustomException;
import com.cg.ibs.im.service.BankerService;
import com.cg.ibs.im.service.BankerServiceImpl;
import com.cg.ibs.im.service.CustomerService;
import com.cg.ibs.im.service.CustomerServiceImpl;

@Component("ui")
public class IdentityManagementUI {
	static Scanner scanner = new Scanner(System.in);

	@Autowired
	private CustomerService customerService;
	@Autowired
	private BankerService bankerService;

	private ApplicantBean applicant = new ApplicantBean();
	private CustomerBean customer = new CustomerBean();

	BufferedReader keyboardInput = new BufferedReader(new InputStreamReader(System.in));

	void init() {
		UserMenu choice = null;
		while (UserMenu.QUIT != choice) {
			System.out.println("------------------------");
			System.out.println("Choose your identity from MENU:");
			System.out.println("------------------------");
			for (UserMenu menu : UserMenu.values()) {
				System.out.println((menu.ordinal()) + 1 + "\t" + menu);
			}
			System.out.println("Choice");
			int ordinalInt = 0;
			try {
				String ordinal = keyboardInput.readLine();

				boolean check = true;
				while (check) {
					if (ordinal.equals("1") || ordinal.equals("2") || ordinal.equals("3") || ordinal.equals("4")) {
						ordinalInt = Integer.parseInt(ordinal);
						check = false;
					} else {
						System.out.println("Please Re-enter: ");
						ordinal = keyboardInput.readLine();
					}
				}

				if (0 < (ordinalInt) && UserMenu.values().length >= (ordinalInt)) {
					choice = UserMenu.values()[ordinalInt - 1];
					switch (choice) {
					case BANK_ADMIN:
						try {
							selectBankerAction();
						} catch (Exception exception) {
							System.out.println(exception.getMessage());
						}
						break;
					case CUSTOMER:
						try {
							selectCustomerAction();
						} catch (Exception exception) {
							System.out.println(exception.getMessage());
						}
						break;
					case SERVICE_PROVIDER:
						selectSPAction();
						break;
					case QUIT:
						System.out.println("Application closed!!");
						break;
					}
				} else {
					System.out.println("Please enter a valid option.");
					choice = null;
				}

			} catch (Exception exception) {
				System.out.println(exception.getMessage());
			}
		}
	}

	public void selectBankerAction() {
		try {
			System.out.println("Enter a login ID:");
			String bankUser = keyboardInput.readLine();
			System.out.println("Enter password:");
			String bankPassword = keyboardInput.readLine();

			while (!bankerService.verifyBankerLogin(bankUser, bankPassword)) {
				System.out.println("Please enter valid details!");
				System.out.println("Enter login Id:");
				bankUser = keyboardInput.readLine();
				System.out.println("Enter password:");
				bankPassword = keyboardInput.readLine();
			}

			BankerAction choice = null;
			while (choice != BankerAction.GO_BACK) {
				System.out.println("------------------------");
				System.out.println("Choose a valid option");
				System.out.println("------------------------");
				for (BankerAction menu : BankerAction.values()) {
					System.out.println(menu.ordinal() + 1 + "\t" + menu);
				}
				System.out.println("Choices:");
				int ordinalInt = 0;
				String ordinal = scanner.next();

				boolean check = true;
				while (check) {
					if (ordinal.equals("1") || ordinal.equals("2") || ordinal.equals("3") || ordinal.equals("4")) {
						ordinalInt = Integer.parseInt(ordinal);
						check = false;
					} else {
						System.out.println("Please Re-enter: ");
						ordinal = scanner.next();
					}
				}

				if (0 < ordinalInt && BankerAction.values().length >= ordinalInt) {
					choice = BankerAction.values()[ordinalInt - 1];
					switch (choice) {
					case VIEW_PENDING_DETAILS:
						try {
							pendingApplications();
						} catch (Exception exception) {
							System.out.println(exception.getMessage());
						}
						break;
					case VIEW_APPROVED_DETAILS:
						approvedApplications();
						break;
					case VIEW_DENIED_DETAILS:
						deniedApplications();
						break;
					case GO_BACK:
						System.out.println("BACK ON HOME PAGE!!");
						break;
					}
				} else {
					System.out.println("Please enter a valid option.");
					choice = null;
				}
			}
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
		}
	}

	public void pendingApplications() {
		try {
			Set<Long> pendingList = bankerService.viewPendingApplications();
			while (pendingList.size() > 0) {
				System.out.println("The list of the pending applicants is here:");

				System.out.println("-----------------------------------------------------------------");
				System.out.println("Applicant Id\tApplication Date\tAccount Type");
				System.out.println("-----------------------------------------------------------------");
				Iterator<Long> pendingIterator = pendingList.iterator();
				while (pendingIterator.hasNext()) {
					try {
						Long applicantId = pendingIterator.next();
						if (customerService.getApplicantDetails(applicantId).getLinkedApplication()
								.equals(new Long(555))) {
							continue;
						} else {
							System.out.println(applicantId + "\t\t"
									+ customerService.getApplicantDetails(applicantId).getApplicationDate() + "\t\t"
									+ customerService.getApplicantDetails(applicantId).getAccountType());
						}

					} catch (Exception exception) {
						System.out.println(exception.getMessage());
					}
				}

				// list printed
				System.out.println("-----------------------------------------------------------------");
				System.out.println("Enter an application number to check details:");
				Long applicantId = scanner.nextLong();

				while (!bankerService.isApplicantPresentInPendingList(applicantId)) {
					System.out.println("Applicant is not present. Please enter a valid id:");
					applicantId = scanner.nextLong();
				}

				applicant = bankerService.displayDetails(applicantId);
				if (applicant.getAccountType() == AccountType.SAVINGS) {
					System.out.println("--------------------------------");
					System.out.println(applicant.toString());
					if (!bankerService.download(applicant)) {
						System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
						System.out.println("Documents haven't been uploaded");
					}
				} else {
					// JOINT ACCOUNT
					System.out.println("--------------------------------");
					System.out.println("Account Type JOINT\nPrimary Customer:");
					System.out.println(applicant.toString());
					if (!bankerService.download(applicant)) {
						System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
						System.out.println("Documents haven't been uploaded");
					}
					System.out.println("--------------------------------");
					Long linked = applicant.getLinkedApplication();

					ApplicantBean applicant1 = bankerService.displayDetails(linked);
					System.out.println(applicant1.toString());
					if (!bankerService.download(applicant1)) {
						System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
						System.out.println("Documents haven't been uploaded");
					}
				}

				// Ask banker to download documentsssss.

				System.out.println("------------------------");
				System.out.println("Choose valid option:");
				System.out.println("------------------------");
				System.out.println("1.\tApprove application");
				System.out.println("2.\tDeny application");
				System.out.println("3.\tLeave");
				try {
					String choice = keyboardInput.readLine();

					while (!choice.equals("1") && !choice.equals("2") && !choice.equals("3")) {
						System.out.println("Please enter a valid choice");
						choice = keyboardInput.readLine();
					}

					if (choice.equals("1")) {
						// CODE FOR APPROVAL

						applicant.setApplicantStatus(ApplicantStatus.APPROVED);
						// update in dao

						if (applicant.getAccountType() == AccountType.JOINT_SAVINGS) {
							customerService.updateApplicant(applicant);
							customer = bankerService.createNewCustomer(applicant);

							System.out.println("The status has been approved for the applicant.\nCustomer"
									+ " ID for Primary customer: " + customer.getUci());
							// joint account
							// CREATE Csutomers and account number

						} else if (applicant.getAccountType() == AccountType.SAVINGS) {
							customerService.updateApplicant(applicant);
							customer = bankerService.createNewCustomer(applicant);
							System.out.println("The status has been approved for the applicant.\nCustomer"
									+ " ID for new customer: " + customer.getUci());
						}
					} else if (choice.equals("2")) {
						applicant.setApplicantStatus(ApplicantStatus.DENIED);

						System.out.println("The application has been denied.");
						System.out.println("Kindly specify the reason for denial: ");
						String remarks = keyboardInput.readLine();
						applicant.setRemarks(remarks);
						customerService.updateApplicant(applicant);
					}
				} catch (Exception exception) {
					System.out.println(exception.getMessage());
				}

				// CODE HERE TODO

				pendingList = bankerService.viewPendingApplications();
				try {
					if (pendingList.size() > 0) {
						System.out.println("Do you want to keep reviewing applications?\n1.\tyes\n2.\tno");
						String continueChoice = keyboardInput.readLine();
						while (!continueChoice.equals("1") && !continueChoice.equals("2")) {
							System.out.println(
									"Please enter an appropriate value. Do you want to keep reviewing applications?\n1. yes\n2. no");
							continueChoice = keyboardInput.readLine();
						}
						if (continueChoice.equals("2")) {
							break;
						}
					}
				} catch (Exception exception) {
					System.out.println(exception.getMessage());
				}
			}
			if (pendingList.size() == 0) {
				System.out.println("There are no pending applicant requests.");

			}
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
		}
	}

	public void approvedApplications() {
		try {

			Set<Long> approvedList = bankerService.viewApprovedApplications();

			if (approvedList.size() > 0) {
				System.out.println("The list of the approved applications is here: ");
				for (long applicantId : approvedList) {

					System.out.println(
							applicantId + "\t" + customerService.getApplicantDetails(applicantId).getAccountType());

				}
			} else {
				System.out.println("There are no approved applications.");
			}
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
		}
	}

	public void deniedApplications() {
		try {

			Set<Long> deniedList = bankerService.viewDeniedApplications();

			if (deniedList.size() > 0) {
				System.out.println("The list of the denied applications is here: ");
				for (Long applicantId : deniedList) {

					System.out.println(
							applicantId + "\t" + customerService.getApplicantDetails(applicantId).getAccountType());

				}
			} else {
				System.out.println("There are no denied applications.");
			}
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
		}
	}

	public void selectCustomerAction() {
		CustomerMenu choice = null;
		while (choice != CustomerMenu.GO_BACK) {
			System.out.println("------------------------");
			System.out.println("Choose an appropriate option from MENU:");
			System.out.println("------------------------");
			for (CustomerMenu menu : CustomerMenu.values()) {
				System.out.println(menu.ordinal() + 1 + "\t" + menu);
			}
			System.out.println("Choice");
			int ordinal = scanner.nextInt();

			if (0 < ordinal && UserMenu.values().length >= ordinal) {
				choice = CustomerMenu.values()[ordinal - 1];
				switch (choice) {
				case SIGNUP:
					try {
						signUp();
					} catch (Exception exception) {
						System.out.println(exception.getMessage());
					}
					break;
				case LOGIN:
					try {
						login();
					} catch (Exception exception) {
						System.out.println(exception.getMessage());
					}
					break;
				case CHECK_STATUS:
					try {
						checkStatus();
					} catch (Exception exception) {
						System.out.println(exception.getMessage());
					}
					break;
				case GO_BACK:
					System.out.println("Going back...");
					break;
				}
			} else {
				System.out.println("Please enter a valid option.");
				choice = null;
			}
		}
	}

	public void signUp() {
		try {
			System.out.println(
					"Do you want to create an individual account or a joint account?\n1. Individual\n2. Joint");
			String typeOfAccount = keyboardInput.readLine();
			while (!typeOfAccount.equals("1") && !typeOfAccount.equals("2")) {
				System.out.println("Please enter a valid choice. Do you want to create an individual account "
						+ "or a joint account?\n1. Individual\n2. Joint");
				typeOfAccount = keyboardInput.readLine();
			}

			if (typeOfAccount.equals("1")) {
				System.out.println("Enter the following details: ");
				System.out.println("--------------------------------------");
				newApplication(applicant);
				applicant.setAccountType(AccountType.SAVINGS);
				applicant.setApplicantStatus(ApplicantStatus.PENDING);
				applicant.setApplicationDate(LocalDate.now());
				applicant.setRemarks("none");
				applicant.setLinkedApplication(new Long(0));
				applicant.setExistingCustomer(false);
//				Long addressId = customerService.saveAddress(applicant.getAddress());
				Long applicantId = customerService.saveApplicantDetails(applicant);
				System.out.println("Your applicant id has been generated: " + applicantId);
				System.out.println("Keep updated with your status.");
				System.out.println("-----------------------------------------------");
				// CONTINUE

			} else if (typeOfAccount.equals("2")) {
				// JOINT ACCOUNT!!!!!
				System.out.println("Enter the following details for PRIMARY customer: ");
				System.out.println("--------------------------------------------------");
				applicant = new ApplicantBean();
				newApplication(applicant);
				applicant.setAccountType(AccountType.JOINT_SAVINGS);
				applicant.setApplicantStatus(ApplicantStatus.PENDING);
				applicant.setApplicationDate(LocalDate.now());
				applicant.setRemarks("none");
				applicant.setLinkedApplication(new Long(0));
				applicant.setExistingCustomer(false);
//				Long addressId = customerService.saveAddress(applicant.getAddress());
				Long applicantId = customerService.saveApplicantDetails(applicant);

				// TODO in progresss!!!!!!!!!!

				ApplicantBean applicant1 = new ApplicantBean();
				System.out.println("Enter the following details for SECONDARY customer: ");
				System.out.println("----------------------------------------------------");
				newApplication(applicant1);
				applicant1.setAccountType(AccountType.JOINT_SAVINGS);
				applicant1.setApplicantStatus(ApplicantStatus.PENDING);
				applicant1.setApplicationDate(LocalDate.now());
				applicant1.setRemarks("none");
				applicant1.setLinkedApplication(new Long(555));
				applicant1.setExistingCustomer(false);
//				Long addressId1 = customerService.saveAddress(applicant1.getAddress());
				Long applicantId1 = customerService.saveApplicantDetails(applicant1);

				applicant.setLinkedApplication(applicantId1);
				customerService.updateApplicant(applicant1);

				// update linked application id of first applicant

				System.out.println("Your applicant id has been generated: " + applicantId);
				System.out.println("Keep updated with your status.");
				System.out.println("-----------------------------------------------");
			}
		} catch (Exception exception) {
			exception.printStackTrace();
		}
	}

	void newApplication(ApplicantBean applicant) {
		System.out.println("Enter the first name");
		try {
			String firstName = keyboardInput.readLine();
			while (!customerService.verifyName(firstName)) {
				System.out.println("Please enter an appropriate first name");
				firstName = keyboardInput.readLine();
			}
			applicant.setFirstName(firstName);
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
		}

		System.out.println("Enter the last name");
		try {
			String lastName = keyboardInput.readLine();
			while (!customerService.verifyName(lastName)) {
				System.out.println("Please enter an appropriate last name");
				lastName = keyboardInput.readLine();
			}
			applicant.setLastName(lastName);
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
		}

		System.out.println("Enter Father's name");
		try {
			String fatherName = keyboardInput.readLine();
			while (!customerService.verifyName(fatherName)) {
				System.out.println("Please enter an appropriate father's name");
				fatherName = keyboardInput.readLine();
			}
			applicant.setFatherName(fatherName);
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
		}

		System.out.println("Enter Mother's name");
		try {
			String motherName = keyboardInput.readLine();
			while (!customerService.verifyName(motherName)) {
				System.out.println("Please enter an appropriate mother's name");
				motherName = keyboardInput.readLine();
			}
			applicant.setMotherName(motherName);
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
		}

		System.out.println("Enter your Date of Birth in DD-MM-YYYY format");
		try {
			String date = null;
			DateTimeFormatter dtFormat = DateTimeFormatter.ofPattern("dd-MM-yyyy");

			LocalDate localDate = null;
			CustomerService customer = new CustomerServiceImpl();

			while (localDate == null || !customer.verifyDob(localDate)) {
				date = keyboardInput.readLine();

				Pattern pattern = Pattern.compile("((3[01])|([12][0-9])|(0[1-9]))\\-((1[0-2])|(0[1-9]))\\-([0-9]{4})");
				Matcher matcher = pattern.matcher(date);
				if (matcher.matches()) {
					localDate = LocalDate.parse(date, dtFormat);
					if (!customer.verifyDob(localDate)) {
						System.out.println("Please Re-enter.Your age should be greater than 18 and less than 110");
					}

				} else {
					System.out.println("Enter a valid date of birth in correct format(dd-MM-yyyy).");
					localDate = null;
				}
			}
			applicant.setDob(localDate);
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
		}

		Gender genderChoice = null;
		System.out.println("Choose your gender from the menu:");
		for (Gender menu : Gender.values()) {
			System.out.println(menu.ordinal() + 1 + "\t" + menu);
		}
		System.out.println("Choice");
		try {
			int gender = 0;
			String ordinal = keyboardInput.readLine();
			boolean check = true;
			while (check) {
				if (ordinal.equals("1") || ordinal.equals("2") || ordinal.equals("3")) {
					gender = Integer.parseInt(ordinal);
					check = false;
				} else {
					System.out.println("Please re-enter a valid option");
					ordinal = keyboardInput.readLine();
				}
			}

			if (0 < gender && Gender.values().length >= gender) {
				genderChoice = Gender.values()[gender - 1];
				switch (genderChoice) {
				case MALE:
					applicant.setGender(Gender.MALE);
					break;
				case FEMALE:
					applicant.setGender(Gender.FEMALE);
					break;
				case PREFER_NOT_TO_SAY:
					applicant.setGender(Gender.PREFER_NOT_TO_SAY);
					break;
				}
			}
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
		}

		// Address
		applicant.setAddress(addAddress(applicant));

		System.out.println("Enter Mobile number");
		String mobileNumber = scanner.next();
		while (!customerService.verifyMobileNumber(mobileNumber)) {
			System.out.println("Please enter an appropriate phone number");
			mobileNumber = scanner.next();
		}
		applicant.setMobileNumber(mobileNumber);

		System.out.println("Enter Alternate Mobile Number");
		String alternateMobileNumber = scanner.next();
		while (!customerService.verifyMobileNumber(alternateMobileNumber)) {
			System.out.println("Please enter an appropriate phone number");
			alternateMobileNumber = scanner.next();
		}

		while (customerService.verifyMobileNumbers(mobileNumber, alternateMobileNumber)) {
			System.out.println("Alternate mobile number can't be the same as primary mobile number");
			alternateMobileNumber = scanner.next();
			while (!customerService.verifyMobileNumber(alternateMobileNumber)) {
				System.out.println("Please enter an appropriate phone number");
				alternateMobileNumber = scanner.next();
			}
		}
		applicant.setAlternateMobileNumber(alternateMobileNumber);

		System.out.println("Enter email id");
		try {
			String emailId = keyboardInput.readLine();
			while (!customerService.verifyEmailId(emailId)) {
				System.out.println("Please enter an appropriate email Id");
				emailId = keyboardInput.readLine();
			}
			applicant.setEmailId(emailId);
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
		}

		System.out.println("Enter Aadhar Number");
		try {
			String aadharNumber = keyboardInput.readLine();
			while (!customerService.verifyAadharNumber(aadharNumber)) {
				System.out.println("Please enter an appropriate aadhar number");
				aadharNumber = keyboardInput.readLine();
			}
			applicant.setAadharNumber(aadharNumber);
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
		}

		System.out.println("Enter Pan Number");
		String panNumber = scanner.next();
		while (!customerService.verifyPanNumber(panNumber)) {
			System.out.println("Please enter an appropriate PAN number");
			panNumber = scanner.next();
		}
		applicant.setPanNumber(panNumber);

		boolean check1 = false;
		while (check1 == false) {

			try {
				uploadDocuments(applicant);
				check1 = true;
			} catch (IOException exp) {
				check1 = false;
				System.out.println("Kindly Upload the correct documents");
			} catch (IBSCustomException exp1) {
				System.out.println("Kindly Upload the correct documents");
			}
		}
	}

	public void uploadDocuments(ApplicantBean applicant) throws IOException, IBSCustomException {

		System.out.println("Enter file path for Aadhar Card:");
		String aadharPath = keyboardInput.readLine();
		System.out.println("Enter file path for Pan Card:");
		String panPath = keyboardInput.readLine();
		customerService.uploadDocuments(applicant, aadharPath, panPath);

	}

	public AddressBean addAddress(ApplicantBean applicant) {
		AddressBean address = new AddressBean();
		System.out.println("Enter your permanent address:");
		System.out.println("-----------------------------");
		try {
			System.out.println("House Number:");
			String houseNumber = keyboardInput.readLine();
			while (houseNumber.length() == 0) {
				System.out.println("Please enter an appropriate house number.");
				houseNumber = keyboardInput.readLine();
			}
			address.setPermanentHouseNumber(houseNumber);

			System.out.println("Street Name:");
			String streetName = keyboardInput.readLine();
			while (streetName.length() == 0) {
				System.out.println("Please enter an appropriate street name.");
				streetName = keyboardInput.readLine();
			}
			address.setPermanentStreetName(streetName);

			System.out.println("Landmark:");
			String landmark = keyboardInput.readLine();
			while (landmark.length() == 0) {
				System.out.println("Please enter an appropriate landmark name.");
				landmark = keyboardInput.readLine();
			}
			address.setPermanentLandmark(landmark);

			System.out.println("Area:");
			String area = keyboardInput.readLine();
			while (area.length() == 0) {
				System.out.println("Please enter an appropriate area name.");
				area = keyboardInput.readLine();
			}
			address.setPermanentArea(area);

			System.out.println("City:");
			String city = keyboardInput.readLine();
			while (city.length() == 0) {
				System.out.println("Please enter an appropriate city name.");
				city = keyboardInput.readLine();
			}
			address.setPermanentCity(city);

			System.out.println("State:");
			String state = keyboardInput.readLine();
			while (state.length() == 0) {
				System.out.println("Please enter an appropriate state name.");
				state = keyboardInput.readLine();
			}
			address.setPermanentState(state);

			System.out.println("Country:");
			String country = keyboardInput.readLine();
			while (country.length() == 0) {
				System.out.println("Please enter an appropriate country name.");
				country = keyboardInput.readLine();
			}
			address.setPermanentCountry(country);

			System.out.println("Pincode:");
			String pinCode = keyboardInput.readLine();
			while (!customerService.verifyPincode(pinCode)) {
				System.out.println("Please enter an appropriate pincode");
				pinCode = keyboardInput.readLine();
			}
			address.setPermanentPincode(pinCode);

			System.out.println("Is your current address same as permanent address?\n1. yes\n2. no");
			String addressSame = keyboardInput.readLine();

			while (!addressSame.equals("1") && !addressSame.equals("2")) {
				System.out.println("Please enter a valid choice. Is your current address same as"
						+ " permanent address?\1. yes\n2. no");
				addressSame = keyboardInput.readLine();
			}

			if (addressSame.equals("1")) {
				address.setCurrentHouseNumber(houseNumber);
				address.setCurrentStreetName(streetName);
				address.setCurrentArea(area);
				address.setCurrentLandmark(landmark);
				address.setCurrentCity(city);
				address.setCurrentState(state);
				address.setCurrentCountry(country);
				address.setCurrentPincode(pinCode);
			} else if (addressSame.equals("2")) {
				System.out.println("----------------------------");
				System.out.println("Enter your current address: ");
				System.out.println("House Number:");
				String permanentHouseNumber = keyboardInput.readLine();
				while (permanentHouseNumber.length() == 0) {
					System.out.println("Please enter an appropriate house number.");
					permanentHouseNumber = keyboardInput.readLine();
				}
				address.setCurrentHouseNumber(permanentHouseNumber);

				System.out.println("Street Name:");
				String permanentStreetName = keyboardInput.readLine();
				while (permanentStreetName.length() == 0) {
					System.out.println("Please enter an appropriate street name.");
					permanentStreetName = keyboardInput.readLine();
				}
				address.setCurrentStreetName(permanentStreetName);

				System.out.println("Landmark:");
				String permanentLandmark = keyboardInput.readLine();
				while (permanentLandmark.length() == 0) {
					System.out.println("Please enter an appropriate landmark name.");
					permanentLandmark = keyboardInput.readLine();
				}
				address.setCurrentLandmark(permanentLandmark);

				System.out.println("Area:");
				String permanentArea = keyboardInput.readLine();
				while (permanentArea.length() == 0) {
					System.out.println("Please enter an appropriate area name.");
					permanentArea = keyboardInput.readLine();
				}
				address.setCurrentArea(permanentArea);

				System.out.println("City:");
				String permanentCity = keyboardInput.readLine();
				while (permanentCity.length() == 0) {
					System.out.println("Please enter an appropriate city name.");
					permanentCity = keyboardInput.readLine();
				}
				address.setCurrentCity(permanentCity);

				System.out.println("State:");
				String permanentState = keyboardInput.readLine();
				while (permanentState.length() == 0) {
					System.out.println("Please enter an appropriate state name.");
					permanentState = keyboardInput.readLine();
				}
				address.setCurrentState(permanentState);

				System.out.println("Country:");
				String permanentCountry = keyboardInput.readLine();
				while (permanentCountry.length() == 0) {
					System.out.println("Please enter an appropriate country name.");
					permanentCountry = keyboardInput.readLine();
				}
				address.setCurrentCountry(permanentCountry);

				System.out.println("Pincode:");
				String permanentPinCode = keyboardInput.readLine();
				while (!customerService.verifyPincode(permanentPinCode)) {
					System.out.println("Please enter an appropriate pincode");
					permanentPinCode = keyboardInput.readLine();
				}
				address.setCurrentPincode(permanentPinCode);

			}
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
		}
		return address;
	}

	public void login() {
		// TODO

		try {
			System.out.println("Please enter the user ID to login");
			String userId = keyboardInput.readLine();
			System.out.println("Enter the password");
			String password = keyboardInput.readLine();

			while (customerService.isCustomerValid(userId) == false) {
				System.out.println("-----------------------------------------");
				System.out.println("INVALID DETAILS! Enter the details again.");
				System.out.println("Please enter the UCI to login");
				userId = keyboardInput.readLine();
				System.out.println("Enter the password");
				password = keyboardInput.readLine();
			}

			if (customerService.login(userId, password)) { // change function
				customer = customerService.getCustomerDetails(userId); // change function
				if (customerService.firstLogin(userId)) { // change function
					firstLogin(userId, password); // change function //DONE
				}
			}

			System.out.println("----------------------------------");
			System.out.println("Hello " + customer.getFirstName() + ", Welcome to the Home Page!!");
			System.out.println("----------------------------------");
			System.out.println("Your accounts: ");

			Set<AccountHoldingBean> userAccountHoldings = customer.getAccountHoldings();
			for (AccountHoldingBean ahb : userAccountHoldings) {
				if (ahb.getCustomer() == customer) {
					System.out.println(ahb.getAccount().getAccType() + " account:\t" + ahb.getAccount().getAccNo());
				}
			}

			// TODO
//			System.out.println("----------------------------------");
//			System.out.println("TABS");
//			System.out.println("1.\tOpen another account.");
//			System.out.println("2.\tSign Out");
//			System.out.println("----------------------------------");

			// TODO
		} catch (Exception exception) {
			//
		}
	}

	public void firstLogin(String userId, String password) {
		try {
			customer = customerService.getCustomerDetails(userId); // change function
			System.out.println("Reset your password");
			String userPassword = keyboardInput.readLine();
			System.out.println("Confirm password");
			String confirmPassword = keyboardInput.readLine();
			while (!customerService.checkCustomerDetails(userPassword, confirmPassword)) {
				System.out.println("Passwords don't match.");
				System.out.println("Enter password again");
				userPassword = keyboardInput.readLine();
				System.out.println("Confirm the password");
				confirmPassword = keyboardInput.readLine();
			}
			try {
				customer.setPassword(confirmPassword);
				customer.setLogin(new Integer(1));
				customerService.updateCustomer(customer);
				System.out.println("Password updated");
			} catch (Exception exception) {
				System.out.println(exception.getMessage());
			}

		} catch (Exception exception) {
			exception.printStackTrace();
		}
	}

	public void checkStatus() {
		// TODO

		System.out.println("Enter the applicant ID to check status:");
		try {
			Long applicantId;
			while (!scanner.hasNextLong()) {
				System.out.println("Enter a valid Applicant ID!");
				scanner.next();
				scanner.nextLine();
			}
			applicantId = scanner.nextLong();
			while (!customerService.verifyApplicantId(applicantId)) {
				System.out.println("Please enter a valid applicant ID");
				applicantId = scanner.nextLong();
				// CHECK !!!!!!!!!!!!!!!!
			}
			ApplicantStatus status = customerService.checkStatus(applicantId);
			System.out.println("Your application status is: " + status);

			applicant = customerService.getApplicantDetails(applicantId);

			if (status == ApplicantStatus.APPROVED) {
				if (applicant.getAccountType() == AccountType.SAVINGS) {
					customer = customerService.getCustomerByApplicantId(applicantId);
					System.out.println("----------------------------------");
					System.out.println("UCI: " + customer.getUci());
					if (customer.getLogin() == 0) {
						System.out.println("UserId: " + customer.getUserId());
						System.out.println("Password for login: " + customer.getPassword());
						for (AccountHoldingBean aHB : customer.getAccountHoldings()) {
							System.out.println("Account number: " + aHB.getAccount().getAccNo());
						}
					}
				} else if (applicant.getAccountType() == AccountType.JOINT_SAVINGS) {
					customer = customerService.getCustomerByApplicantId(applicantId);
					// doesn't show anything for PR customer
					System.out.println("----------------------------------");
					System.out.println("For Primary Customer:");
					System.out.println("UCI: " + customer.getUci());
					if (customer.getLogin() == 0) {
						System.out.println("UserId: " + customer.getUserId());
						System.out.println("Password for login: " + customer.getPassword());
					}

					Long linkedApplication = applicant.getLinkedApplication();
					CustomerBean customer1 = customerService.getCustomerByApplicantId(linkedApplication);
					System.out.println("----------------------------------");
					System.out.println("For Secondary Customer:");
					System.out.println("UCI: " + customer1.getUci());
					if (customer.getLogin() == 0) {
						System.out.println("UserId: " + customer1.getUserId());
						System.out.println("Password for login: " + customer1.getPassword());
					}
					System.out.println("----------------------------------");
					// CHECK ACCOUNT!!
//					for (AccountHoldingBean aHB : customer.getAccountHoldings()) {
//						System.out.println("Account number: " + aHB.getAccount().getAccNo());
//					}

					Set<AccountHoldingBean> userAccountHoldings = customer.getAccountHoldings();
					for (AccountHoldingBean ahb : userAccountHoldings) {
						if (ahb.getCustomer() == customer) {
							System.out.println(
									ahb.getAccount().getAccType() + " account:\t" + ahb.getAccount().getAccNo());
						}
					}
				}
			}

			if (status == ApplicantStatus.DENIED) {
				System.out.println("The application has been denied.");
				System.out.println("-------------------------------------------------");
				System.out.println("Reason stated by Bank admin: " + applicant.getRemarks());
			}

		} catch (Exception exception) {
			exception.printStackTrace();
		}

	}

	public void selectSPAction() {
		System.out.println("Under Maintainence. (Use-Case 4!)");
	}

}
