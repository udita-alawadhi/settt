package com.cg.ibs.im.dao;

import java.math.BigInteger;

import com.cg.ibs.im.bean.AccountBean;
import com.cg.ibs.im.exception.IBSCustomException;

public interface AccountDao {

	public BigInteger saveAccount(AccountBean account) throws IBSCustomException;

	boolean checkAccountExists(BigInteger accountNumber) throws IBSCustomException;

}
