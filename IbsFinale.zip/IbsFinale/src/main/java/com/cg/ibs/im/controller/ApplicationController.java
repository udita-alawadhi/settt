package com.cg.ibs.im.controller;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ibs.im.model.Application;
import com.cg.ibs.im.service.CustomerService;

@RestController
@RequestMapping("/application")
public class ApplicationController {
	
	@Autowired
	private CustomerService customerService;
	
	@GetMapping
	public ResponseEntity<Set<Application>> getAllApplications() {
		try {
			return new ResponseEntity<Set<Application>>(customerService.getAllApplications(), HttpStatus.OK);
		} catch (Exception exception) {
			Set<Application> set = new HashSet<Application>();
			return new ResponseEntity<Set<Application>>(set, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
