package com.cg.ibs.im.dao;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.ibs.im.exception.IBSCustomException;
import com.cg.ibs.im.exception.IBSException;
import com.cg.ibs.im.model.Application;
import com.cg.ibs.im.model.ApplicationStatus;

@Repository("applicationDao")
public class ApplicationDaoImpl implements ApplicationDao {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public Long saveApplication(Application application) throws IBSCustomException {
		Long applicationId = new Long(0);
		if (application != null) {
			entityManager.persist(application);
			applicationId = application.getApplicationId();
		} else {
			throw new IBSCustomException(IBSException.SQLError);
		}
		return applicationId;
	}

	@Override
	public Application getApplicationDetails(Long applicationId) throws IBSCustomException {
		Application newApplication = new Application();
		if (isApplicationPresent(applicationId)) {

			newApplication = entityManager.find(Application.class, applicationId);

		} else {
			throw new IBSCustomException(IBSException.SQLError);
		}
		return newApplication;
	}

	@Override
	public Set<Application> getAllApplications() throws IBSCustomException {
		TypedQuery<Application> query = entityManager.createNamedQuery("getAllApplications", Application.class);
		List<Application> applicationSet = query.getResultList();
		Set<Application> applications = new HashSet<Application>();
		for (Application application : applicationSet) {
			applications.add(application);
		}
		return applications;
	}

	@Override
	public Set<Application> getApplicationByStatus(ApplicationStatus applicationStatus) throws IBSCustomException {
		TypedQuery<Application> query = entityManager.createNamedQuery("getApplicationsByStatus", Application.class);
		// set applicantStatus
		query.setParameter("applicationStatus", applicationStatus);
		List<Application> applicationSet = query.getResultList();
		Set<Application> applications = new HashSet<Application>();
		for (Application application : applicationSet) {
			applications.add(application);
		}
		return applications;
	}

	@Override
	public boolean isApplicationPresent(Long applicationId) throws IBSCustomException {
		boolean result = false;
		Application newApplication = entityManager.find(Application.class, applicationId);
		if (newApplication != null) {
			result = true;
		}
		return result;
	}

	@Override
	public boolean updateApplication(Application application) throws IBSCustomException {
		boolean result = false;
		if (application != null) {
			entityManager.merge(application);
			result = true;
		} else {
			throw new IBSCustomException(IBSException.SQLError);
		}
		return result;
	}
}
