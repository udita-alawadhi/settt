package com.cg.ibs.im.controller;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ibs.im.exception.IBSCustomException;
import com.cg.ibs.im.model.AccountType;
import com.cg.ibs.im.model.Applicant;
import com.cg.ibs.im.model.Application;
import com.cg.ibs.im.model.Customer;
import com.cg.ibs.im.model.Message;
import com.cg.ibs.im.service.BankerService;
import com.cg.ibs.im.service.CustomerService;

@RestController
@RequestMapping("/customer")
@Scope("session")
@CrossOrigin
public class CustomerController {

	@Autowired
	private CustomerService customerService;
	@Autowired
	private BankerService bankerService;

	private Customer cust;

	@PostMapping
	public ResponseEntity<Message> customerLogin(@RequestBody Customer customer) {
		ResponseEntity<Message> result;
		Message message = new Message();
		System.out.println("sdhwe");
		try {
			if (customer.getUserId() == null || customer.getUserId().equals("")) {
				message.setMessage("No user details found");
				result = new ResponseEntity<>(message, HttpStatus.BAD_REQUEST);
			} else {
				try {
					if (customerService.login(customer.getUserId(), customer.getPassword())) {
						cust = customerService.getCustomerDetails(customer.getUserId());
						System.out.println("reached");
						message.setMessage("Welcome " + cust.getFirstName() + " " + cust.getLastname());
						message.setCustomer(cust);
						result = new ResponseEntity<>(message, HttpStatus.OK);
					} else {
						message.setMessage("Unauthorised User - INCORRECT USERNAME/PASSWORD");
						result = new ResponseEntity<>(message, HttpStatus.UNAUTHORIZED);
					}
				} catch (IBSCustomException exception) {
					message.setMessage("Unauthorised User  - INCORRECT USERNAME/PASSWORD");
					result = new ResponseEntity<>(message, HttpStatus.UNAUTHORIZED);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			message.setMessage("Internal Issue");
			result = new ResponseEntity<>(message, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		System.out.println(result);
		return result;
	}

	@GetMapping
	public ResponseEntity<Set<Customer>> getAllCustomers() {
		try {
			return new ResponseEntity<Set<Customer>>(customerService.getAllCustomers(), HttpStatus.OK);
		} catch (Exception exception) {
			Set<Customer> set = new HashSet<Customer>();
			return new ResponseEntity<Set<Customer>>(set, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping(value = "/checkStatus/{applicationId}")
    public ResponseEntity<Message> applicationStatus(@PathVariable("applicationId") Long applicationId) {
        System.out.println("reached here check status");
		ResponseEntity<Message> result;
        Message message = new Message();
        try {
            Application application = bankerService.displayDetails(applicationId);
            String accountType = application.getAccountType().toString();
            message.setMessage(customerService.checkStatus(applicationId).toString());
            message.setApplication(application);
            if (message == null) {
                result = new ResponseEntity<Message>(message, HttpStatus.BAD_REQUEST);
            } else if (message.getMessage().equals("APPROVED")) {
                Customer customer = customerService.getCustomerByApplicantId(applicationId);
                message.setCustomer(customer);
                if (application.getAccountType() == AccountType.SAVINGS) {
                    
                    result = new ResponseEntity<Message>(message, HttpStatus.OK);
                } else {
                
                    result = new ResponseEntity<Message>(message, HttpStatus.OK);
                }
            } else if (message.equals("DENIED")) {
                result = new ResponseEntity<Message>(message, HttpStatus.OK);
            } else {
                result = new ResponseEntity<Message>(message, HttpStatus.OK);
            }
        } catch (IBSCustomException exception) {
        	message.setMessage("Applicant ID is invalid");
            result = new ResponseEntity<Message>(message, HttpStatus.BAD_REQUEST);
        }
        return result;
    }
}