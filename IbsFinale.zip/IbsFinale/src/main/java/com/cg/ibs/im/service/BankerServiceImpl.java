package com.cg.ibs.im.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.im.dao.AccountDao;
import com.cg.ibs.im.dao.ApplicantDao;
import com.cg.ibs.im.dao.ApplicationDao;
import com.cg.ibs.im.dao.BankerDao;
import com.cg.ibs.im.dao.CustomerDao;
import com.cg.ibs.im.exception.IBSCustomException;
import com.cg.ibs.im.model.Account;
import com.cg.ibs.im.model.AccountHolding;
import com.cg.ibs.im.model.AccountHoldingType;
import com.cg.ibs.im.model.AccountStatus;
import com.cg.ibs.im.model.AccountType;
import com.cg.ibs.im.model.Applicant;
import com.cg.ibs.im.model.ApplicationStatus;
import com.cg.ibs.im.model.Application;
import com.cg.ibs.im.model.Customer;

@Service("bankerService")
public class BankerServiceImpl implements BankerService {

	@Autowired
	private BankerDao bankerDao;
	@Autowired
	private ApplicantDao applicantDao;
	@Autowired
	private CustomerDao customerDao;
	@Autowired
	private AccountDao accountDao;
	@Autowired
	private ApplicationDao applicationDao;
	
	private static Logger LOGGER = Logger.getLogger(BankerServiceImpl.class);
	


	@Override
	public boolean verifyBankerLogin(String user, String password) throws IBSCustomException {
		LOGGER.info("In verifyBankerLogin method");
		boolean result = false;
		result = bankerDao.checkBankerLogin(user, password);
		return result;
	}

	@Override
	public Set<Application> viewPendingApplications() throws IBSCustomException {
		LOGGER.info("In viewPendingApplications method");

		return applicationDao.getApplicationByStatus(ApplicationStatus.PENDING);
	}

	@Override
	public Set<Application> viewPendingApplicationsBanker(Integer bankerId) throws IBSCustomException {
		LOGGER.info("In viewPendingApplications method");

		Set<Application> applications = applicationDao.getApplicationByStatus(ApplicationStatus.PENDING);
		Set<Application> pendingBanker = new HashSet<Application>();
		for(Application a: applications) {
			if(a.getAssignedBanker()==bankerId) {
				pendingBanker.add(a);
			}
		}
		return pendingBanker;
	}

	@Override
	public Set<Application> viewApprovedApplications() throws IBSCustomException {
		LOGGER.info("In viewApprovedApplications method");

		return applicationDao.getApplicationByStatus(ApplicationStatus.APPROVED);
	}
	
	@Override
	public Set<Application> viewDeniedApplications() throws IBSCustomException {
		LOGGER.info("In viewDeniedApplications method");

		return applicationDao.getApplicationByStatus(ApplicationStatus.DENIED);
	}
	
	@Override
	public String generatePassword(Long applicantId) {
		LOGGER.info("In generatePassword method");

		String alphaNumeric = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "0123456789" + "abcdefghijklmnopqrstuvxyz";
		StringBuilder stringBuffer = new StringBuilder(8);

		for (int i = 0; i < 8; i++) {
			int index = (int) (alphaNumeric.length() * Math.random());
			stringBuffer.append(alphaNumeric.charAt(index));
		}
		return stringBuffer.toString();
	}

	@Override
	public boolean isApplicantPresentInPendingList(Long applicantId) throws IBSCustomException {
		LOGGER.info("In isApplicantPresentInPendingList method");

		boolean result = false;
		if (applicantId != 0) {
			LOGGER.debug("applicantId is not zero");

			Set<Applicant> pendingApplicants = applicantDao.getApplicantsByStatus(ApplicationStatus.PENDING);
			Iterator<Applicant> it = pendingApplicants.iterator();
			while (it.hasNext()) {
				if (it.next().getApplicantId() == applicantId) {
					result = true;
					break;
				}
			}
		}
		return result;
	}

	@Override
	public boolean isApplicantPresent(Long applicantId) throws IBSCustomException {
		return applicantDao.isApplicantPresent(applicantId);
	}

	@Override
	public Application displayDetails(Long applicationId) throws IBSCustomException {
		
		Application application = applicationDao.getApplicationDetails(applicationId);
		
		return application;
	}

	@Override
	public String generateUsername(Long applicantId) throws IBSCustomException {
		Applicant applicant = applicantDao.getApplicantDetails(applicantId);

		String username = applicant.getFirstName().charAt(0) + applicant.getLastName();
		if (username.length() > 12) {
			username = username.substring(0, 10);
		}
		int index = 1;
		while (!checkUsernameIsUnique(username)) {
			username = username.concat(String.valueOf(index));
			if (username.length() > 15) {
				username = username.substring(0, 14);
			}
			index++;
		}
		return username;
	}

	public boolean checkUsernameIsUnique(String username) {
		boolean result = true;
		try {
			if (customerDao.checkCustomerByUsernameExists(username)) {
				result = false;
			}
		} catch (Exception exception) {
			exception.getMessage();
		}
		return result;
	}

	@Override
	public boolean download(Applicant applicant) throws IBSCustomException {
		boolean result = false;
		byte[] aadhar = applicant.getAadharDocument();
		byte[] pan = applicant.getPanDocument();
		File dir = new File("./downloads");
		if (!dir.exists()) {
			dir.mkdir();
		}
		try (FileOutputStream outputStream1 = new FileOutputStream(
				dir.getPath() + "/" + applicant.getApplicantId() + "aadhar.pdf");
				FileOutputStream outputStream2 = new FileOutputStream(
						dir.getPath() + "/" + applicant.getApplicantId() + "pan.pdf")) {
			outputStream1.write(aadhar);
			outputStream1.flush();
			outputStream1.close();
			outputStream2.write(pan);
			outputStream2.flush();
			outputStream2.close();
			result = true;
		} catch (FileNotFoundException e) {
			e.getMessage();
		} catch (IOException e) {
			e.getMessage();
		}
		return result;

	}
	
	@Transactional
	@Override
	public boolean updateCustomer(Customer customer) throws IBSCustomException {
		boolean result = false;
		result = customerDao.updateCustomer(customer);
		return result;
	}

	@Transactional
	@Override
	public Customer createNewCustomer(Application application) throws IBSCustomException {
		Customer customer = new Customer();
		
		Long applicationId = application.getApplicationId();
		
		customer.setPassword(generatePassword(applicationId));
		
		customer.setApplicationId(applicationId);
		Applicant applicant = application.getPrimaryApplicant();
		String userId = generateUsername(applicant.getApplicantId());
		
		customer.setUserId(userId);
		customer.setFirstName(applicant.getFirstName());
		customer.setLastname(applicant.getLastName());
		customer.setFatherName(applicant.getFatherName());
		customer.setMotherName(applicant.getMotherName());
		customer.setDateofBirth(applicant.getDob());
		customer.setGender(applicant.getGender());
		customer.setMobileNumber(applicant.getMobileNumber());
		customer.setAlternateMobileNumber(applicant.getAlternateMobileNumber());
		customer.setEmailId(applicant.getEmailId());
		customer.setAadharNumber(applicant.getAadharNumber());
		customer.setPanNumber(applicant.getPanNumber());
		customer.setLogin(new Integer(0));
		customer.setAddress(applicant.getAddress());
		Set<AccountHolding> ah = new HashSet<AccountHolding>();
		customer.setAccountHoldings(ah);
		AccountHolding accountHolding = new AccountHolding();

		Customer result=customerDao.saveCustomer(customer);
		Account account = createNewAccount(application);
		
		if(application.getAccountType()==AccountType.JOINT_SAVINGS) {
			Customer customer1 = new Customer();
			Applicant applicant1 = application.getSecondaryApplicant();
			String userId1 = generateUsername(applicant1.getApplicantId());
			
			customer1.setUserId(userId1);
			
			customer1.setApplicationId(applicationId);
			customer1.setPassword(generatePassword(applicationId));
			customer1.setFirstName(applicant1.getFirstName());
			customer1.setLastname(applicant1.getLastName());
			customer1.setFatherName(applicant1.getFatherName());
			customer1.setMotherName(applicant1.getMotherName());
			customer1.setDateofBirth(applicant1.getDob());
			customer1.setGender(applicant1.getGender());
			customer1.setMobileNumber(applicant1.getMobileNumber());
			customer1.setAlternateMobileNumber(applicant1.getAlternateMobileNumber());
			customer1.setEmailId(applicant1.getEmailId());
			customer1.setAadharNumber(applicant1.getAadharNumber());
			customer1.setPanNumber(applicant1.getPanNumber());
			customer1.setLogin(new Integer(0));
			customer1.setAddress(applicant1.getAddress());
			
			Set<AccountHolding> ah1 = new HashSet<AccountHolding>();
			customer1.setAccountHoldings(ah1);
			AccountHolding accountHolding1 = new AccountHolding();
			
			Customer result1 = customerDao.saveCustomer(customer1);
			
			accountHolding1.setAccount(account);
			accountHolding1.setCustomer(result1);
			accountHolding1.setType(AccountHoldingType.SECONDARY);
			
			customer1.getAccountHoldings().add(accountHolding1);
			
			accountHolding.setAccount(account);
			accountHolding.setCustomer(result);
			accountHolding.setType(AccountHoldingType.PRIMARY);
			
			customer.getAccountHoldings().add(accountHolding);
			
			account.getAccountHoldings().add(accountHolding);
			account.getAccountHoldings().add(accountHolding1);
			
			
		} else { 
			accountHolding.setAccount(account);
			accountHolding.setCustomer(result);
			accountHolding.setType(AccountHoldingType.INDIVIDUAL);
			
			customer.getAccountHoldings().add(accountHolding);
			account.getAccountHoldings().add(accountHolding);
			
		}
		
		return result;
	}
	
	public Account createNewAccount(Application application) throws IBSCustomException {
		Account account = new Account();
		BigInteger accNo = new BigInteger("0");
		
		account.setAccCreationDate(LocalDate.now());
		account.setAccStatus(AccountStatus.ACTIVE);
		account.setAccType(application.getAccountType());
		account.setBalance(new BigDecimal(0));
		account.setOpenBalance(new BigDecimal(0));
		account.setTrans_Pwd("1111");
		
		Set<AccountHolding> ah = new HashSet<AccountHolding>();
		account.setAccountHoldings(ah);
		accNo = accountDao.saveAccount(account);
		return account;
	}
	
	public boolean updateAccountHoldingsCustomer(Customer customer, AccountHolding accountHolding) throws IBSCustomException {
		boolean result = false;
		
		BigInteger uci = customer.getUci();
		Customer cust = customerDao.getCustomerByUci(uci);
		Set<AccountHolding> customerHoldings = cust.getAccountHoldings();
		customerHoldings.add(accountHolding);
		cust.setAccountHoldings(customerHoldings);
		return result;
	}
}
