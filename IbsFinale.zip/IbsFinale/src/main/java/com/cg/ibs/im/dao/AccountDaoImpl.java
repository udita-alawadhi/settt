package com.cg.ibs.im.dao;

import java.math.BigInteger;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.cg.ibs.im.model.Account;
import com.cg.ibs.im.exception.IBSCustomException;
import com.cg.ibs.im.exception.IBSException;

@Repository("accountDao")
public class AccountDaoImpl implements AccountDao {
	private static Logger LOGGER = Logger.getLogger(AccountDaoImpl.class);

	@PersistenceContext
	private EntityManager entityManager;
	private Account account = new Account();

	@Override
	public BigInteger saveAccount(Account account) throws IBSCustomException {
		LOGGER.info("In saveAccount method");
		BigInteger result = new BigInteger("0");
		if (account != null) {
			LOGGER.debug("Account exists.");
			entityManager.persist(account);
			LOGGER.info("Account saved");
			result = account.getAccNo();
		} else {
			LOGGER.error("Account not added properly");
			throw new IBSCustomException(IBSException.SQLError);
		}
		return result;
	}

	@Override
	public boolean checkAccountExists(BigInteger accountNumber) throws IBSCustomException {
		LOGGER.info("In checkAccountExists method");
		boolean result = false;
		account = entityManager.find(Account.class, accountNumber);
		if (account != null) {
			LOGGER.debug("Account exists.");
			result = true;
		}
		return result;
	}
	
	@Override
	public Account getAccount(BigInteger accountNumber) throws IBSCustomException {
		Account account = new Account();
		if(checkAccountExists(accountNumber)) {
			account = entityManager.find(Account.class, accountNumber);
		} else {
			throw new IBSCustomException(IBSException.accountNotPresent);
		}
		return account;
	}
} 
