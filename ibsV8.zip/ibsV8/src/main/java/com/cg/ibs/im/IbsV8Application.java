package com.cg.ibs.im;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;

@SpringBootApplication
public class IbsV8Application {

	public static void main(String[] args) {
		System.out.println("pune");

		Methods method  = new Methods();
		
		method.signUp();
		
		try {
			
		} catch (Exception exception) {
			exception.printStackTrace();
		}
	}

}
