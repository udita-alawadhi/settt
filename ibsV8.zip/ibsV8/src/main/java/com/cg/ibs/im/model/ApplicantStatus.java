package com.cg.ibs.im.model;

public enum ApplicantStatus {
	PENDING, APPROVED, DENIED;
}
