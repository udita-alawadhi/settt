package com.cg.ibs.im.dao;

import java.math.BigInteger;

import com.cg.ibs.im.model.Account;
import com.cg.ibs.im.exception.IBSCustomException;

public interface AccountDao {

	public BigInteger saveAccount(Account account) throws IBSCustomException;

	boolean checkAccountExists(BigInteger accountNumber) throws IBSCustomException;

}
