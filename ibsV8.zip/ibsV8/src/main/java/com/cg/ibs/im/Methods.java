package com.cg.ibs.im;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.stereotype.Controller;

import com.cg.ibs.im.exception.IBSCustomException;
import com.cg.ibs.im.model.Address;
import com.cg.ibs.im.model.Applicant;
import com.cg.ibs.im.model.Gender;
import com.cg.ibs.im.service.BankerService;
import com.cg.ibs.im.service.BankerServiceImpl;
import com.cg.ibs.im.service.CustomerService;
import com.cg.ibs.im.service.CustomerServiceImpl;

@Controller
public class Methods {
	private static Scanner scanner = new Scanner(System.in);
	private BufferedReader keyboardInput = new BufferedReader(new InputStreamReader(System.in));
	
	
	private CustomerService customerService = new CustomerServiceImpl();
	
	private BankerService bankerService = new BankerServiceImpl();
	
	public void signUp() {
		try {
			System.out.println("Enter the following details: ");
			System.out.println("--------------------------------------");
			
			Applicant applicant = new Applicant();
			newApplication(applicant);

			Long applicantId = customerService.saveApplicantDetails(applicant);
			System.out.println("Your applicant id has been generated: " + applicantId);
			System.out.println("Keep updated with your status.");
			System.out.println("-----------------------------------------------");
			
		} catch (Exception exception) {
			exception.printStackTrace();
		}
	}
	
	
	public void newApplication(Applicant applicant) {
		System.out.println("Enter the first name");
		try {
			String firstName = keyboardInput.readLine();
			System.out.println(customerService.verifyName(firstName));
			while (!customerService.verifyName(firstName)) {
				System.out.println("Please enter an appropriate first name");
				firstName = keyboardInput.readLine();
			}
			applicant.setFirstName(firstName);
		} catch (Exception exception) {
			exception.printStackTrace();
		}

		System.out.println("Enter the last name");
		try {
			String lastName = keyboardInput.readLine();
			while (!customerService.verifyName(lastName)) {
				System.out.println("Please enter an appropriate last name");
				lastName = keyboardInput.readLine();
			}
			applicant.setLastName(lastName);
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
		}

		System.out.println("Enter Father's name");
		try {
			String fatherName = keyboardInput.readLine();
//			while (!customerService.verifyName(fatherName)) {
//				System.out.println("Please enter an appropriate father's name");
//				fatherName = keyboardInput.readLine();
//			}
			applicant.setFatherName(fatherName);
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
		}

		System.out.println("Enter Mother's name");
		try {
			String motherName = keyboardInput.readLine();
			while (!customerService.verifyName(motherName)) {
				System.out.println("Please enter an appropriate mother's name");
				motherName = keyboardInput.readLine();
			}
			applicant.setMotherName(motherName);
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
		}

		System.out.println("Enter your Date of Birth in DD-MM-YYYY format");
		try {
			String date = null;
			DateTimeFormatter dtFormat = DateTimeFormatter.ofPattern("dd-MM-yyyy");

			LocalDate localDate = null;
			CustomerService customer = new CustomerServiceImpl();

			while (localDate == null || !customer.verifyDob(localDate)) {
				date = keyboardInput.readLine();

				Pattern pattern = Pattern.compile("((3[01])|([12][0-9])|(0[1-9]))\\-((1[0-2])|(0[1-9]))\\-([0-9]{4})");
				Matcher matcher = pattern.matcher(date);
				if (matcher.matches()) {
					localDate = LocalDate.parse(date, dtFormat);
					if (!customer.verifyDob(localDate)) {
						System.out.println("Please Re-enter.Your age should be greater than 18 and less than 110");
					}

				} else {
					System.out.println("Enter a valid date of birth in correct format(dd-MM-yyyy).");
					localDate = null;
				}
			}
			applicant.setDob(localDate);
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
		}

		Gender genderChoice = null;
		System.out.println("Choose your gender from the menu:");
		for (Gender menu : Gender.values()) {
			System.out.println(menu.ordinal() + 1 + "\t" + menu);
		}
		System.out.println("Choice");
		try {
			int gender = 0;
			String ordinal = keyboardInput.readLine();
			boolean check = true;
			while (check) {
				if (ordinal.equals("1") || ordinal.equals("2") || ordinal.equals("3")) {
					gender = Integer.parseInt(ordinal);
					check = false;
				} else {
					System.out.println("Please re-enter a valid option");
					ordinal = keyboardInput.readLine();
				}
			}

			if (0 < gender && Gender.values().length >= gender) {
				genderChoice = Gender.values()[gender - 1];
				switch (genderChoice) {
				case MALE:
					applicant.setGender(Gender.MALE);
					break;
				case FEMALE:
					applicant.setGender(Gender.FEMALE);
					break;
				case PREFER_NOT_TO_SAY:
					applicant.setGender(Gender.PREFER_NOT_TO_SAY);
					break;
				}
			}
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
		}

		// Address
		applicant.setAddress(addAddress(applicant));

		System.out.println("Enter Mobile number");
		String mobileNumber = scanner.next();
		while (!customerService.verifyMobileNumber(mobileNumber)) {
			System.out.println("Please enter an appropriate phone number");
			mobileNumber = scanner.next();
		}
		applicant.setMobileNumber(mobileNumber);

		System.out.println("Enter Alternate Mobile Number");
		String alternateMobileNumber = scanner.next();
		while (!customerService.verifyMobileNumber(alternateMobileNumber)) {
			System.out.println("Please enter an appropriate phone number");
			alternateMobileNumber = scanner.next();
		}

		while (customerService.verifyMobileNumbers(mobileNumber, alternateMobileNumber)) {
			System.out.println("Alternate mobile number can't be the same as primary mobile number");
			alternateMobileNumber = scanner.next();
			while (!customerService.verifyMobileNumber(alternateMobileNumber)) {
				System.out.println("Please enter an appropriate phone number");
				alternateMobileNumber = scanner.next();
			}
		}
		applicant.setAlternateMobileNumber(alternateMobileNumber);

		System.out.println("Enter email id");
		try {
			String emailId = keyboardInput.readLine();
			while (!customerService.verifyEmailId(emailId)) {
				System.out.println("Please enter an appropriate email Id");
				emailId = keyboardInput.readLine();
			}
			applicant.setEmailId(emailId);
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
		}

		System.out.println("Enter Aadhar Number");
		try {
			String aadharNumber = keyboardInput.readLine();
			while (!customerService.verifyAadharNumber(aadharNumber)) {
				System.out.println("Please enter an appropriate aadhar number");
				aadharNumber = keyboardInput.readLine();
			}
			applicant.setAadharNumber(aadharNumber);
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
		}

		System.out.println("Enter Pan Number");
		String panNumber = scanner.next();
		while (!customerService.verifyPanNumber(panNumber)) {
			System.out.println("Please enter an appropriate PAN number");
			panNumber = scanner.next();
		}
		applicant.setPanNumber(panNumber);

//		boolean check1 = false;
//		while (check1 == false) {
//
//			try {
//				uploadDocuments(applicant);
//				check1 = true;
//			} catch (IOException exp) {
//				check1 = false;
//				System.out.println("Kindly Upload the correct documents");
//			} catch (IBSCustomException exp1) {
//				System.out.println("Kindly Upload the correct documents");
//			}
//		}
	}
	
	public Address addAddress(Applicant applicant) {
		Address address = new Address();
		System.out.println("Enter your permanent address:");
		System.out.println("-----------------------------");
		try {
			System.out.println("House Number:");
			String houseNumber = keyboardInput.readLine();
			while (houseNumber.length() == 0) {
				System.out.println("Please enter an appropriate house number.");
				houseNumber = keyboardInput.readLine();
			}
			address.setPermanentHouseNumber(houseNumber);

			System.out.println("Street Name:");
			String streetName = keyboardInput.readLine();
			while (streetName.length() == 0) {
				System.out.println("Please enter an appropriate street name.");
				streetName = keyboardInput.readLine();
			}
			address.setPermanentStreetName(streetName);

			System.out.println("Landmark:");
			String landmark = keyboardInput.readLine();
			while (landmark.length() == 0) {
				System.out.println("Please enter an appropriate landmark name.");
				landmark = keyboardInput.readLine();
			}
			address.setPermanentLandmark(landmark);

			System.out.println("Area:");
			String area = keyboardInput.readLine();
			while (area.length() == 0) {
				System.out.println("Please enter an appropriate area name.");
				area = keyboardInput.readLine();
			}
			address.setPermanentArea(area);

			System.out.println("City:");
			String city = keyboardInput.readLine();
			while (city.length() == 0) {
				System.out.println("Please enter an appropriate city name.");
				city = keyboardInput.readLine();
			}
			address.setPermanentCity(city);

			System.out.println("State:");
			String state = keyboardInput.readLine();
			while (state.length() == 0) {
				System.out.println("Please enter an appropriate state name.");
				state = keyboardInput.readLine();
			}
			address.setPermanentState(state);

			System.out.println("Country:");
			String country = keyboardInput.readLine();
			while (country.length() == 0) {
				System.out.println("Please enter an appropriate country name.");
				country = keyboardInput.readLine();
			}
			address.setPermanentCountry(country);

			System.out.println("Pincode:");
			String pinCode = keyboardInput.readLine();
			while (!customerService.verifyPincode(pinCode)) {
				System.out.println("Please enter an appropriate pincode");
				pinCode = keyboardInput.readLine();
			}
			address.setPermanentPincode(pinCode);

			System.out.println("Is your current address same as permanent address?\n1. yes\n2. no");
			String addressSame = keyboardInput.readLine();

			while (!addressSame.equals("1") && !addressSame.equals("2")) {
				System.out.println("Please enter a valid choice. Is your current address same as"
						+ " permanent address?\1. yes\n2. no");
				addressSame = keyboardInput.readLine();
			}

			if (addressSame.equals("1")) {
				address.setCurrentHouseNumber(houseNumber);
				address.setCurrentStreetName(streetName);
				address.setCurrentArea(area);
				address.setCurrentLandmark(landmark);
				address.setCurrentCity(city);
				address.setCurrentState(state);
				address.setCurrentCountry(country);
				address.setCurrentPincode(pinCode);
			} else if (addressSame.equals("2")) {
				System.out.println("----------------------------");
				System.out.println("Enter your current address: ");
				System.out.println("House Number:");
				String permanentHouseNumber = keyboardInput.readLine();
				while (permanentHouseNumber.length() == 0) {
					System.out.println("Please enter an appropriate house number.");
					permanentHouseNumber = keyboardInput.readLine();
				}
				address.setCurrentHouseNumber(permanentHouseNumber);

				System.out.println("Street Name:");
				String permanentStreetName = keyboardInput.readLine();
				while (permanentStreetName.length() == 0) {
					System.out.println("Please enter an appropriate street name.");
					permanentStreetName = keyboardInput.readLine();
				}
				address.setCurrentStreetName(permanentStreetName);

				System.out.println("Landmark:");
				String permanentLandmark = keyboardInput.readLine();
				while (permanentLandmark.length() == 0) {
					System.out.println("Please enter an appropriate landmark name.");
					permanentLandmark = keyboardInput.readLine();
				}
				address.setCurrentLandmark(permanentLandmark);

				System.out.println("Area:");
				String permanentArea = keyboardInput.readLine();
				while (permanentArea.length() == 0) {
					System.out.println("Please enter an appropriate area name.");
					permanentArea = keyboardInput.readLine();
				}
				address.setCurrentArea(permanentArea);

				System.out.println("City:");
				String permanentCity = keyboardInput.readLine();
				while (permanentCity.length() == 0) {
					System.out.println("Please enter an appropriate city name.");
					permanentCity = keyboardInput.readLine();
				}
				address.setCurrentCity(permanentCity);

				System.out.println("State:");
				String permanentState = keyboardInput.readLine();
				while (permanentState.length() == 0) {
					System.out.println("Please enter an appropriate state name.");
					permanentState = keyboardInput.readLine();
				}
				address.setCurrentState(permanentState);

				System.out.println("Country:");
				String permanentCountry = keyboardInput.readLine();
				while (permanentCountry.length() == 0) {
					System.out.println("Please enter an appropriate country name.");
					permanentCountry = keyboardInput.readLine();
				}
				address.setCurrentCountry(permanentCountry);

				System.out.println("Pincode:");
				String permanentPinCode = keyboardInput.readLine();
				while (!customerService.verifyPincode(permanentPinCode)) {
					System.out.println("Please enter an appropriate pincode");
					permanentPinCode = keyboardInput.readLine();
				}
				address.setCurrentPincode(permanentPinCode);

			}
		} catch (Exception exception) {
			System.out.println(exception.getMessage());
		}
		return address;
	}
	
	public String checkStatus(Long applicantId) {
		String result = "";
		try {
			result = customerService.checkStatus(applicantId).toString();
		} catch(Exception exception) {
			exception.printStackTrace();
		}
		return result;
	}
	
	public boolean bankerLogin(String userId, String pass) throws IBSCustomException {
		return bankerService.verifyBankerLogin(userId, pass);
	}
}
