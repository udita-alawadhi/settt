package com.cg.ibs.im.model;
public enum TransactionType {
	 CREDIT, DEBIT;
}
