package com.cg.ibs.im.model;

import java.math.BigInteger;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "account_applicants")
public class AccountApplicant {

	@Id
	@Column(name = "account_applicant_id")
	private Long accountApplicantId;
	@Column(name = "account_type")
	private AccountType accountType;
	@Column(name = "account_application_status")
	private ApplicantStatus accountApplicationStatus;
	@Column(name = "account_application_date")
	private LocalDate accountApplicationDate;
	@Column(name = "primary_customer")
	private BigInteger primaryCustomer;
	@Column(name = "secondary_customer")
	private BigInteger secondaryCustomer;

	public Long getAccountApplicantId() {
		return accountApplicantId;
	}

	public void setAccountApplicantId(Long accountApplicantId) {
		this.accountApplicantId = accountApplicantId;
	}

	public AccountType getAccountType() {
		return accountType;
	}

	public void setAccountType(AccountType accountType) {
		this.accountType = accountType;
	}

	public ApplicantStatus getAccountApplicationStatus() {
		return accountApplicationStatus;
	}

	public void setAccountApplicationStatus(ApplicantStatus accountApplicationStatus) {
		this.accountApplicationStatus = accountApplicationStatus;
	}

	public LocalDate getAccountApplicationDate() {
		return accountApplicationDate;
	}

	public void setAccountApplicationDate(LocalDate accountApplicationDate) {
		this.accountApplicationDate = accountApplicationDate;
	}

	public BigInteger getPrimaryCustomer() {
		return primaryCustomer;
	}

	public void setPrimaryCustomer(BigInteger primaryCustomer) {
		this.primaryCustomer = primaryCustomer;
	}

	public BigInteger getSecondaryCustomer() {
		return secondaryCustomer;
	}

	public void setSecondaryCustomer(BigInteger secondaryCustomer) {
		this.secondaryCustomer = secondaryCustomer;
	}
}
